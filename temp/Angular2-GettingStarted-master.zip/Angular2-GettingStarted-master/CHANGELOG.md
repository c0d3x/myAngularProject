#Changes made to the course since its release:
- The course was updated for Angular 2 Final on October 18, 2016.

